/* Includes */
#include "main.h"
#include <stdio.h>
#include <string.h>

/* Private variables */
ADC_HandleTypeDef hadc1;
UART_HandleTypeDef huart2;

/* Function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
static void MX_USART2_UART_Init(void);
uint32_t Read_ADC(uint32_t channel);

#define UMBRAL_PISADA 200
#define MAX_PISADAS 10

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_USART2_UART_Init();

  uint32_t sensores[6];
  uint32_t maximos[6] = {0};
  uint32_t historial[MAX_PISADAS][6] = {0};
  int evento_activo = 0;
  int zona_inicial = -1;
  int total_pisadas = 0;
  char msg[512];

  while (1)
  {
    sensores[0] = Read_ADC(ADC_CHANNEL_0);
    sensores[1] = Read_ADC(ADC_CHANNEL_1);
    sensores[2] = Read_ADC(ADC_CHANNEL_4);
    sensores[3] = Read_ADC(ADC_CHANNEL_8);
    sensores[4] = Read_ADC(ADC_CHANNEL_11);
    sensores[5] = Read_ADC(ADC_CHANNEL_10);

    if (!evento_activo)
    {
      for (int i = 0; i < 6; i++)
      {
        if (sensores[i] > UMBRAL_PISADA)
        {
          zona_inicial = i;
          evento_activo = 1;
          break;
        }
      }
    }

    if (evento_activo)
    {
      for (int i = 0; i < 6; i++)
      {
        if (sensores[i] > maximos[i])
        {
          maximos[i] = sensores[i];
        }
      }

      int activos = 0;
      for (int i = 0; i < 6; i++)
      {
        if (sensores[i] > UMBRAL_PISADA)
          activos++;
      }

      if (activos == 0)
      {
        snprintf(msg, sizeof(msg),
                 "[PISADA %d REGISTRADA]\r\nFuerzas: %lu, %lu, %lu, %lu, %lu, %lu\r\n",
                 total_pisadas + 1,
                 maximos[0], maximos[1], maximos[2],
                 maximos[3], maximos[4], maximos[5]);
        HAL_UART_Transmit(&huart2, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

        for (int i = 0; i < 6; i++)
          historial[total_pisadas][i] = maximos[i];

        total_pisadas++;

        for (int i = 0; i < 6; i++)
          maximos[i] = 0;
        zona_inicial = -1;
        evento_activo = 0;
      }
    }

    if (total_pisadas == MAX_PISADAS)
    {
      uint32_t promedios[6] = {0};
      for (int i = 0; i < MAX_PISADAS; i++)
      {
        for (int j = 0; j < 6; j++)
        {
          promedios[j] += historial[i][j];
        }
      }
      for (int i = 0; i < 6; i++)
        promedios[i] /= MAX_PISADAS;

      uint32_t prom_talon = (promedios[0] + promedios[1]);
      uint32_t prom_mediopie = (promedios[2] + promedios[3]);
      uint32_t prom_antepie = (promedios[4] + promedios[5]);
      uint32_t total = prom_talon + prom_mediopie + prom_antepie;

      uint32_t pct_talon = (prom_talon * 100) / total;
      uint32_t pct_mediopie = (prom_mediopie * 100) / total;
      uint32_t pct_antepie = (prom_antepie * 100) / total;

      const char *zona = "";
      const char *riesgo = "";
      const char *consejo = "";

      if (prom_talon > prom_mediopie && prom_talon > prom_antepie)
      {
        zona = "Talon";
        riesgo = "Impacto vertical constante, puede generar sobrecarga en rodillas.";
        consejo = "Mejorar tecnica para que el impacto se distribuya mejor.";
      }
      else if (prom_mediopie > prom_antepie)
      {
        zona = "Mediopie";
        riesgo = "Buena distribucion general, pero puede sobrecargar gemelos.";
        consejo = "Alternar ejercicios de tecnica y reforzar musculatura.";
      }
      else
      {
        zona = "Antepie";
        riesgo = "Mayor exigencia muscular y carga en metatarsos.";
        consejo = "Asegurar calentamiento y calzado con buena amortiguacion.";
      }

      snprintf(msg, sizeof(msg),
               "\r\n[ANALISIS DE 10 PISADAS]\r\nZona dominante: %s\r\nDistribucion: Talon: %lu%%, Mediopie: %lu%%, Antepie: %lu%%\r\nRiesgo: %s\r\nConsejo: %s\r\n\r\n",
               zona, pct_talon, pct_mediopie, pct_antepie, riesgo, consejo);
      HAL_UART_Transmit(&huart2, (uint8_t *)msg, strlen(msg), HAL_MAX_DELAY);

      total_pisadas = 0;
    }

    HAL_Delay(50);
  }
}

uint32_t Read_ADC(uint32_t channel)
{
  ADC_ChannelConfTypeDef sConfig = {0};
  sConfig.Channel = channel;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;

  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
  HAL_ADC_Start(&hadc1);
  HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);

  return HAL_ADC_GetValue(&hadc1);
}

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 84;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  HAL_RCC_OscConfig(&RCC_OscInitStruct);

  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2);
}

static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
}

static void MX_ADC1_Init(void)
{
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  HAL_ADC_Init(&hadc1);

  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
}

static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&huart2);
}
